# Split Files
##### Execute
`python split_files.py <csv/text_file> <split/line_number`
