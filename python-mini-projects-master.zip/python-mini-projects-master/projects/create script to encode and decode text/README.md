## create script to encode and decode text

### usage

python aes_encode.py "a text"

example:
    python aes_encode.py "hello world"

An encrypted file("encrypted.bin") will be generated after the program is run