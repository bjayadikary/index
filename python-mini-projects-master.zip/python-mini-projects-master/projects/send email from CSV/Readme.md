# Send Emails from CSV File

### Emails.csv : - Here CSV file Contain List Of Emails

### Credentials.txt : -Contain information about Yoour Email

1. Your Email Address
2. Your Email Password

### CSV module :- As it is lightweight than Pandas.
