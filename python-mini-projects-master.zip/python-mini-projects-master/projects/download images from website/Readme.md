# Scrap images from URL

1. Dowmload Chrome Drive From Chrome.
2. Run scrap-img.py file `py scrap-img.py`
3. `Enter Path : E:\webscraping\chromedriver_win32\chromedriver.exe` <br/>
   `Enter URL : https://dribbble.com/`
