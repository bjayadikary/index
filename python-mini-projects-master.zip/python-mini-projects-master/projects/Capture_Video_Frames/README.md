# Capture Video Frames
##### Execute
`python capture_video_frames.py <video_file>`
